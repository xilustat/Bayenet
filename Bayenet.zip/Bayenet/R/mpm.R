
mpm <- function(x)
{
  if (mean(x) >= 0.5) {1}
  else {0}
}